<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/navigation/header/links--language-block.html.twig */
class __TwigTemplate_89421ace6679ed316c39639b629ceeeeae17b42a4b9e215cba69dc7fc955b245 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 34
        if (($context["links"] ?? null)) {
            // line 35
            echo "<div class=\"nav-item dropdown\">
  <a class=\"nav-link dropdown-toggle\" href=\"#\" data-toggle=\"dropdown\" aria-expanded=\"false\">
    <span>";
            // line 37
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["current_language"] ?? null), 37, $this->source), "html", null, true);
            echo "</span>
    ";
            // line 38
            $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "themes/contrib/bootstrap_italia/templates/navigation/header/links--language-block.html.twig", 38)->display(twig_array_merge($context, ["name" => "it-expand"]));
            // line 39
            echo "  </a>
  <div class=\"dropdown-menu\">
    <div class=\"row\">
      <div class=\"col-12\">
        <div class=\"link-list-wrapper\">
          <ul";
            // line 44
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => "link-list"], "method", false, false, true, 44), 44, $this->source), "html", null, true);
            echo ">";
            // line 45
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["links"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 46
                echo "<li>";
                // line 47
                if (twig_get_attribute($this->env, $this->source, $context["item"], "link", [], "any", false, false, true, 47)) {
                    // line 49
                    echo "                  <!-- ";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "link", [], "any", false, false, true, 49), 49, $this->source), "html", null, true);
                    echo " -->
                  <a";
                    // line 50
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "attributes", [], "any", false, false, true, 50), "addClass", [0 => "list-item"], "method", false, false, true, 50), 50, $this->source), "html", null, true);
                    echo " href=\"";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed((($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["item"], "link", [], "any", false, false, true, 50)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["#url"] ?? null) : null), 50, $this->source), "html", null, true);
                    echo "\">
                    <span>";
                    // line 51
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed((($__internal_compile_1 = twig_get_attribute($this->env, $this->source, $context["item"], "link", [], "any", false, false, true, 51)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["#title"] ?? null) : null), 51, $this->source), "html", null, true);
                    echo "</span>
                  </a>";
                } elseif (twig_get_attribute($this->env, $this->source,                 // line 53
$context["item"], "text_attributes", [], "any", false, false, true, 53)) {
                    // line 54
                    echo "<span";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "text_attributes", [], "any", false, false, true, 54), 54, $this->source), "html", null, true);
                    echo ">";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "text", [], "any", false, false, true, 54), 54, $this->source), "html", null, true);
                    echo "</span>";
                } else {
                    // line 56
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "text", [], "any", false, false, true, 56), 56, $this->source), "html", null, true);
                }
                // line 58
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 60
            echo "</ul>
        </div>
      </div>
    </div>
  </div>
</div>";
        }
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/navigation/header/links--language-block.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 60,  96 => 58,  93 => 56,  86 => 54,  84 => 53,  80 => 51,  74 => 50,  69 => 49,  67 => 47,  65 => 46,  61 => 45,  58 => 44,  51 => 39,  49 => 38,  45 => 37,  41 => 35,  39 => 34,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/navigation/header/links--language-block.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/navigation/header/links--language-block.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 34, "include" => 38, "for" => 45);
        static $filters = array("escape" => 37);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'include', 'for'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
