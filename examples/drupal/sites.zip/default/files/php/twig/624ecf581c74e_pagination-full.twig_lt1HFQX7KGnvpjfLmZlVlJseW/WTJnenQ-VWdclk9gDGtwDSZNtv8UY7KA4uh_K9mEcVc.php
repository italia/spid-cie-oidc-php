<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia_components/pagination/pagination-full.twig */
class __TwigTemplate_772b42786d9d3dd25839b005c907b6aa3ea7be8b4db45be1156baf3429e9833e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 36
        if (($context["items"] ?? null)) {
            // line 37
            echo "<nav class=\"pagination-wrapper justify-content-center\" aria-label=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Paginazione risultati"));
            echo "\">
  <ul class=\"pagination justify-content-center js-pager__items\">
    ";
            // line 40
            echo "    <li class=\"page-item";
            if ( !twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "previous", [], "any", false, false, true, 40)) {
                echo " disabled";
            }
            echo "\">
      <a
        class=\"page-link text\"
        href=\"";
            // line 43
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "previous", [], "any", false, false, true, 43), "href", [], "any", false, false, true, 43), 43, $this->source), "html", null, true);
            echo "\"
        ";
            // line 44
            if ( !twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "previous", [], "any", false, false, true, 44)) {
                echo " tabindex=\"-1\" aria-hidden=\"true\"";
            }
            // line 45
            echo "      >
        ";
            // line 46
            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "previous", [], "any", false, false, true, 46), "text", [], "any", false, false, true, 46)) {
                // line 47
                echo "          <span class=\"sr-only\">";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Pagina"));
                echo "</span>";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Precedente"));
                echo "
        ";
            } else {
                // line 49
                echo "          ";
                $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia_components/pagination/pagination-full.twig", 49)->display(twig_array_merge($context, ["name" => "it-chevron-left", "classes" => [0 => "icon-primary"]]));
                // line 53
                echo "          <span class=\"sr-only\">Pagina precedente</span>
        ";
            }
            // line 55
            echo "      </a>
    </li>

    ";
            // line 58
            if ((twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "first", [], "any", false, false, true, 58) && twig_get_attribute($this->env, $this->source, ($context["ellipses"] ?? null), "previous", [], "any", false, false, true, 58))) {
                // line 59
                echo "      <li class=\"page-item d-none d-sm-flex\">
        <a class=\"page-link\" href=\"";
                // line 60
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "first", [], "any", false, false, true, 60), "href", [], "any", false, false, true, 60), 60, $this->source), "html", null, true);
                echo "\">1</a>
      </li>
    ";
            }
            // line 63
            echo "
    ";
            // line 64
            if (twig_get_attribute($this->env, $this->source, ($context["ellipses"] ?? null), "previous", [], "any", false, false, true, 64)) {
                // line 65
                echo "      <li class=\"page-item d-none d-sm-flex\"><span class=\"page-link\">...</span></li>
    ";
            }
            // line 67
            echo "
    ";
            // line 69
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "pages", [], "any", false, false, true, 69));
            foreach ($context['_seq'] as $context["key"] => $context["item"]) {
                // line 70
                echo "      <li class=\"page-item";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($context["current"] ?? null) == $context["key"])) ? (" active") : (" d-none d-sm-flex")));
                echo "\">
        ";
                // line 71
                if ((($context["current"] ?? null) == $context["key"])) {
                    // line 72
                    echo "          ";
                    $context["title"] = t("Current page");
                    // line 73
                    echo "        ";
                } else {
                    // line 74
                    echo "          ";
                    $context["title"] = t("Go to page @key", ["@key" => $context["key"]]);
                    // line 75
                    echo "        ";
                }
                // line 76
                echo "        <a
          class=\"page-link\" ";
                // line 77
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($context["current"] ?? null) == $context["key"])) ? (" aria-current=\"page\"") : ("")));
                echo "
          href=\"";
                // line 78
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, true, 78), 78, $this->source), "html", null, true);
                echo "\" title=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title"] ?? null), 78, $this->source), "html", null, true);
                echo "\"
          ";
                // line 79
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "attributes", [], "any", false, false, true, 79), 79, $this->source), "href", "title"), "html", null, true);
                echo "
        >
          <span class=\"visually-hidden\">
            ";
                // line 82
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($context["current"] ?? null) == $context["key"])) ? (t("Current page")) : (t("Page"))));
                echo "
          </span>
          ";
                // line 84
                if ((($context["current"] ?? null) == $context["key"])) {
                    // line 85
                    echo "            <span class=\"d-inline-block d-sm-none\">";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Page"));
                    echo " </span>
          ";
                }
                // line 86
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($context["key"], 86, $this->source), "html", null, true);
                echo "
        </a>
      </li>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 90
            echo "
    ";
            // line 91
            if (twig_get_attribute($this->env, $this->source, ($context["ellipses"] ?? null), "next", [], "any", false, false, true, 91)) {
                // line 92
                echo "      <li class=\"page-item d-none d-sm-flex\"><span class=\"page-link\">...</span></li>
    ";
            }
            // line 94
            echo "
    ";
            // line 95
            if ((twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "last", [], "any", false, false, true, 95) && twig_get_attribute($this->env, $this->source, ($context["ellipses"] ?? null), "next", [], "any", false, false, true, 95))) {
                // line 96
                echo "      <li class=\"page-item d-none d-sm-flex\">
        <a class=\"page-link\" href=\"";
                // line 97
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "last", [], "any", false, false, true, 97), "href", [], "any", false, false, true, 97), 97, $this->source), "html", null, true);
                echo "\">";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["total_pages"] ?? null), 97, $this->source), "html", null, true);
                echo "</a>
      </li>
    ";
            }
            // line 100
            echo "
    ";
            // line 101
            if (twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "next", [], "any", false, false, true, 101)) {
                // line 102
                echo "      <li class=\"page-item";
                if ( !twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "next", [], "any", false, false, true, 102)) {
                    echo " disabled";
                }
                echo "\">
        <a
          class=\"page-link text\"
          href=\"";
                // line 105
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "next", [], "any", false, false, true, 105), "href", [], "any", false, false, true, 105), 105, $this->source), "html", null, true);
                echo "\"
          ";
                // line 106
                if ( !twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "next", [], "any", false, false, true, 106)) {
                    echo " tabindex=\"-1\" aria-hidden=\"true\"";
                }
                // line 107
                echo "        >
          ";
                // line 108
                if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["items"] ?? null), "previous", [], "any", false, false, true, 108), "text", [], "any", false, false, true, 108)) {
                    // line 109
                    echo "            <span class=\"sr-only\">";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Pagina"));
                    echo "</span>";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Successiva"));
                    echo "
          ";
                } else {
                    // line 111
                    echo "            <span class=\"sr-only\">Pagina successiva</span>
            ";
                    // line 112
                    $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia_components/pagination/pagination-full.twig", 112)->display(twig_array_merge($context, ["name" => "it-chevron-right", "classes" => [0 => "icon-primary"]]));
                    // line 116
                    echo "          ";
                }
                // line 117
                echo "        </a>
      </li>
    ";
            }
            // line 120
            echo "
  </ul>
</nav>
";
        }
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia_components/pagination/pagination-full.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  251 => 120,  246 => 117,  243 => 116,  241 => 112,  238 => 111,  230 => 109,  228 => 108,  225 => 107,  221 => 106,  217 => 105,  208 => 102,  206 => 101,  203 => 100,  195 => 97,  192 => 96,  190 => 95,  187 => 94,  183 => 92,  181 => 91,  178 => 90,  168 => 86,  162 => 85,  160 => 84,  155 => 82,  149 => 79,  143 => 78,  139 => 77,  136 => 76,  133 => 75,  130 => 74,  127 => 73,  124 => 72,  122 => 71,  117 => 70,  112 => 69,  109 => 67,  105 => 65,  103 => 64,  100 => 63,  94 => 60,  91 => 59,  89 => 58,  84 => 55,  80 => 53,  77 => 49,  69 => 47,  67 => 46,  64 => 45,  60 => 44,  56 => 43,  47 => 40,  41 => 37,  39 => 36,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia_components/pagination/pagination-full.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/src/components/pagination/pagination-full.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 36, "include" => 49, "for" => 69, "set" => 72);
        static $filters = array("t" => 37, "escape" => 43, "without" => 79);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'include', 'for', 'set'],
                ['t', 'escape', 'without'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
