<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/layout/header/_partial.header.html.twig */
class __TwigTemplate_73e6c0b0f260222b353f152e9b103c8d4ba3824beb94b10a098712e966941897 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'header' => [$this, 'block_header'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $this->displayBlock('header', $context, $blocks);
    }

    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "  <header class=\"it-header-wrapper";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["header_sticky"] ?? null)) ? (" it-header-sticky") : ("")));
        echo "\">
    ";
        // line 3
        $this->loadTemplate("@bootstrap_italia/layout/header/_partial.header-slim.html.twig", "@bootstrap_italia/layout/header/_partial.header.html.twig", 3)->display($context);
        // line 4
        echo "    <div class=\"it-nav-wrapper\">
      ";
        // line 5
        $this->loadTemplate("@bootstrap_italia/layout/header/_partial.header-center.html.twig", "@bootstrap_italia/layout/header/_partial.header.html.twig", 5)->display($context);
        // line 6
        echo "      ";
        $this->loadTemplate("@bootstrap_italia/layout/header/_partial.header-navbar.html.twig", "@bootstrap_italia/layout/header/_partial.header.html.twig", 6)->display($context);
        // line 7
        echo "    </div>
  </header>
";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/layout/header/_partial.header.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  62 => 7,  59 => 6,  57 => 5,  54 => 4,  52 => 3,  47 => 2,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/layout/header/_partial.header.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/header/_partial.header.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("block" => 1, "include" => 3);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['block', 'include'],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
