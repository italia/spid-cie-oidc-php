<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia_components/icon/password_icon.twig */
class __TwigTemplate_ded036173eadbf36ab7605f687073119a48219c779a7a8944cd337e48d3cd0ca extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<span class=\"password-icon\" aria-hidden=\"true\">
  ";
        // line 2
        $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia_components/icon/password_icon.twig", 2)->display(twig_array_merge($context, ["name" => "it-password-visible", "classes" => [0 => "password-icon-visible"], "size" => "sm"]));
        // line 7
        echo "  ";
        $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia_components/icon/password_icon.twig", 7)->display(twig_array_merge($context, ["name" => "it-password-invisible", "classes" => [0 => "password-icon-invisible", 1 => "d-none"], "size" => "sm"]));
        // line 12
        echo "</span>
";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia_components/icon/password_icon.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 12,  44 => 7,  42 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia_components/icon/password_icon.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/src/components/icon/password_icon.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("include" => 2);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['include'],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
