<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/layout/regions/region--header-nav.html.twig */
class __TwigTemplate_61b884b924b5a1dcf877bc5f1952995bfb963e5e6c57f3319695263124195af0 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 16
        if (($context["content"] ?? null)) {
            // line 17
            echo "  <div";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "setAttribute", [0 => "id", 1 => ("it-region-" . \Drupal\Component\Utility\Html::getId($this->sandbox->ensureToStringAllowed(            // line 18
($context["region"] ?? null), 18, $this->source)))], "method", false, false, true, 17), "setAttribute", [0 => "class", 1 => ("region " . $this->sandbox->ensureToStringAllowed(            // line 19
($context["region"] ?? null), 19, $this->source))], "method", false, false, true, 18), 19, $this->source), "html", null, true);
            // line 20
            echo ">
    ";
            // line 21
            $context["heading_id"] = "main-menu";
            // line 22
            echo "    <nav
      role=\"navigation\"
      aria-labelledby=\"";
            // line 24
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["heading_id"] ?? null), 24, $this->source), "html", null, true);
            echo "\"
      class=\"navbar navbar-expand-";
            // line 25
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["main_menu_breakpoint_expand"] ?? null), 25, $this->source), "html", null, true);
            echo " has-megamenu\"
    >
      <button class=\"custom-navbar-toggler\" type=\"button\" aria-controls=\"";
            // line 27
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["heading_id"] ?? null), 27, $this->source), "html", null, true);
            echo "\" aria-expanded=\"false\" aria-label=\"Toggle navigation\" data-target=\"#";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["heading_id"] ?? null), 27, $this->source), "html", null, true);
            echo "\">
        ";
            // line 28
            $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "themes/contrib/bootstrap_italia/templates/layout/regions/region--header-nav.html.twig", 28)->display(twig_array_merge($context, ["name" => "it-burger"]));
            // line 29
            echo "      </button>
      <div class=\"navbar-collapsable\" id=\"";
            // line 30
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["heading_id"] ?? null), 30, $this->source), "html", null, true);
            echo "\" style=\"display: none;\">
        <div class=\"overlay\" style=\"display: none;\"></div>
        <div class=\"close-div sr-only\">
          <button class=\"btn close-menu\" type=\"button\"><span class=\"it-close\"></span>";
            // line 33
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Close"));
            echo "</button>
        </div>
        ";
            // line 36
            echo "        <h2 id=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($this->sandbox->ensureToStringAllowed(($context["heading_id"] ?? null), 36, $this->source) . "-title"), "html", null, true);
            echo "\" class=\"visually-hidden\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Main Menu"));
            echo "</h2>
        <div class=\"menu-wrapper\">
          ";
            // line 38
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 38, $this->source), "html", null, true);
            echo "
        </div>
      </div>
    </nav>

  </div>
";
        }
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/layout/regions/region--header-nav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 38,  86 => 36,  81 => 33,  75 => 30,  72 => 29,  70 => 28,  64 => 27,  59 => 25,  55 => 24,  51 => 22,  49 => 21,  46 => 20,  44 => 19,  43 => 18,  41 => 17,  39 => 16,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/layout/regions/region--header-nav.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/regions/region--header-nav.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 16, "set" => 21, "include" => 28);
        static $filters = array("escape" => 19, "clean_id" => 18, "trans" => 33, "t" => 36);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'set', 'include'],
                ['escape', 'clean_id', 'trans', 't'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
