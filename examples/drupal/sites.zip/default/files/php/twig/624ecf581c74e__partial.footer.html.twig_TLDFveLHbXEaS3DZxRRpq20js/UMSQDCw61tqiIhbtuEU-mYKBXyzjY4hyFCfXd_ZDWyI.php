<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/layout/footer/_partial.footer.html.twig */
class __TwigTemplate_23a6bb6d3b04b0e51402930a20c878d3ec5e34abbf52f3e55c4fec5fed4fa9a5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'footer' => [$this, 'block_footer'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $this->displayBlock('footer', $context, $blocks);
    }

    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "  <footer class=\"it-footer\">
    <div class=\"it-footer-main\">
      <div class=\"";
        // line 4
        ((($context["footer_container_type"] ?? null)) ? (print ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["footer_container_type"] ?? null), "html", null, true))) : (print ("container")));
        echo "\">
        ";
        // line 5
        $this->loadTemplate("@bootstrap_italia/layout/footer/_partial.footer-brand.html.twig", "@bootstrap_italia/layout/footer/_partial.footer.html.twig", 5)->display($context);
        // line 6
        echo "        ";
        $this->loadTemplate("@bootstrap_italia/layout/footer/_partial.footer-menu.html.twig", "@bootstrap_italia/layout/footer/_partial.footer.html.twig", 6)->display($context);
        // line 7
        echo "        ";
        $this->loadTemplate("@bootstrap_italia/layout/footer/_partial.footer-blocks.html.twig", "@bootstrap_italia/layout/footer/_partial.footer.html.twig", 7)->display($context);
        // line 8
        echo "      </div>
    </div>
    <div class=\"it-footer-small-prints clearfix\">
      <div class=\"";
        // line 11
        ((($context["footer_container_type"] ?? null)) ? (print ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["footer_container_type"] ?? null), "html", null, true))) : (print ("container")));
        echo "\">
        ";
        // line 12
        $this->loadTemplate("@bootstrap_italia/layout/footer/_partial.footer-small-prints.html.twig", "@bootstrap_italia/layout/footer/_partial.footer.html.twig", 12)->display($context);
        // line 13
        echo "      </div>
    </div>
  </footer>
";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/layout/footer/_partial.footer.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  74 => 13,  72 => 12,  68 => 11,  63 => 8,  60 => 7,  57 => 6,  55 => 5,  51 => 4,  47 => 2,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/layout/footer/_partial.footer.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/footer/_partial.footer.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("block" => 1, "include" => 5);
        static $filters = array("escape" => 4);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['block', 'include'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
