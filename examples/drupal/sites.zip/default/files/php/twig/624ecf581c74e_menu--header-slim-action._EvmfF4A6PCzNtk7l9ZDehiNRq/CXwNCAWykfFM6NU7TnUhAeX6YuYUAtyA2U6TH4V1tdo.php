<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-slim-action.html.twig */
class __TwigTemplate_69297386746bce4db7e54f0980dfdfe46944f0e29c5b021561001b5cb7bfce50 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 21
        echo "<div class=\"nav-item dropdown\">
  <a class=\"nav-link dropdown-toggle\" href=\"#\" data-toggle=\"dropdown\" aria-expanded=\"false\">
    ";
        // line 28
        echo "    <span>";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("User"));
        echo "</span>
    ";
        // line 29
        $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-slim-action.html.twig", 29)->display(twig_array_merge($context, ["name" => "it-expand"]));
        // line 30
        echo "  </a>
  <div class=\"dropdown-menu\">
    <div class=\"row\">
      <div class=\"col-12\">
        ";
        // line 34
        $this->loadTemplate("@bootstrap_italia_components/link-list/menu-recursive.twig", "themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-slim-action.html.twig", 34)->display(twig_array_merge($context, ["menu_name" =>         // line 35
($context["menu_name"] ?? null), "items" =>         // line 36
($context["items"] ?? null), "attributes" =>         // line 37
($context["attributes"] ?? null), "view_link_description" => true, "large" => false, "bold" => false, "icon_position" => "right", "icon_type" => "it-expand", "icon_color" => "white", "active_items_large" => false, "active_items_bold" => false]));
        // line 47
        echo "      </div>
    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-slim-action.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 47,  59 => 37,  58 => 36,  57 => 35,  56 => 34,  50 => 30,  48 => 29,  43 => 28,  39 => 21,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-slim-action.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-slim-action.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("include" => 29);
        static $filters = array("trans" => 28);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['include'],
                ['trans'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
