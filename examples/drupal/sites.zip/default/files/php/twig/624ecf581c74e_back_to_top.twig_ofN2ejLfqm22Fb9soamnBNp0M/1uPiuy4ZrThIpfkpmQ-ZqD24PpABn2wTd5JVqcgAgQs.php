<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia_components/back_to_top/back_to_top.twig */
class __TwigTemplate_38938072086ae20639c4750cc0376d6f4e08d52df14a8da791fdddaeb77003c9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 15
        $context["container_classes"] = [0 => "back-to-top", 1 => ((        // line 17
($context["small"] ?? null)) ? ("back-to-top-small") : ("")), 2 => ((        // line 18
($context["dark"] ?? null)) ? ("dark") : ("")), 3 => ((        // line 19
($context["shadow"] ?? null)) ? ("shadow") : (""))];
        // line 22
        $context["icon_class"] = ((($context["dark"] ?? null)) ? ("icon-secondary") : ("icon-light"));
        // line 23
        echo "
<a href=\"#\" aria-hidden=\"true\" title=\"Back To Top\" data-attribute=\"back-to-top\" class=\"";
        // line 24
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["container_classes"] ?? null), 24, $this->source), " "), "html", null, true);
        echo "\">
  ";
        // line 25
        $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia_components/back_to_top/back_to_top.twig", 25)->display(twig_array_merge($context, ["name" => "it-arrow-up", "classes" => [0 =>         // line 27
($context["icon_class"] ?? null)]]));
        // line 29
        echo "</a>
";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia_components/back_to_top/back_to_top.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 29,  54 => 27,  53 => 25,  49 => 24,  46 => 23,  44 => 22,  42 => 19,  41 => 18,  40 => 17,  39 => 15,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia_components/back_to_top/back_to_top.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/src/components/back_to_top/back_to_top.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 15, "include" => 25);
        static $filters = array("escape" => 24, "join" => 24);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'include'],
                ['escape', 'join'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
