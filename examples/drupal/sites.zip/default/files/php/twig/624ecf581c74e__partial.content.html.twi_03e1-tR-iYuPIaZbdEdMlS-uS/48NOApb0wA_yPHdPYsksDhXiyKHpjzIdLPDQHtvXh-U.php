<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/layout/content/_partial.content.html.twig */
class __TwigTemplate_08f1a623acc23a22bd52ca6ee89e04a5db0d4b3efce16bcd25c483199273a9b5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'sidebar_first' => [$this, 'block_sidebar_first'],
            'sidebar_second' => [$this, 'block_sidebar_second'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo " ";
        $this->displayBlock('main', $context, $blocks);
    }

    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "  <main>
    <div role=\"main\" class=\"";
        // line 3
        ((($context["content_container_type"] ?? null)) ? (print ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["content_container_type"] ?? null), "html", null, true))) : (print ("container")));
        echo " main-container\">
      ";
        // line 4
        if (((((twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 4) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "title", [], "any", false, false, true, 4)) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "local_tasks", [], "any", false, false, true, 4)) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 4)) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "notification", [], "any", false, false, true, 4))) {
            // line 5
            echo "        <div class=\"row\">
          <div class=\"col\">
            ";
            // line 7
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 7)) {
                // line 8
                echo "              <div class=\"it-breadcrumb__wrapper\">
                ";
                // line 9
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 9), 9, $this->source), "html", null, true);
                echo "
              </div>
            ";
            }
            // line 12
            echo "
            ";
            // line 13
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "title", [], "any", false, false, true, 13)) {
                // line 14
                echo "              <div class=\"it-page-title__wrapper\">
                ";
                // line 15
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "title", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
                echo "
              </div>
            ";
            }
            // line 18
            echo "
            ";
            // line 19
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "local_tasks", [], "any", false, false, true, 19)) {
                // line 20
                echo "              <div class=\"it-local-tasks_wrapper mb-5\">
                ";
                // line 21
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "local_tasks", [], "any", false, false, true, 21), 21, $this->source), "html", null, true);
                echo "
              </div>
            ";
            }
            // line 24
            echo "
            ";
            // line 25
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 25)) {
                // line 26
                echo "              <div class=\"it-help__wrapper\">
                ";
                // line 27
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 27), 27, $this->source), "html", null, true);
                echo "
              </div>
            ";
            }
            // line 30
            echo "
            ";
            // line 31
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "notification", [], "any", false, false, true, 31)) {
                // line 32
                echo "              <div class=\"it-notification__wrapper\">
                ";
                // line 33
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "notification", [], "any", false, false, true, 33), 33, $this->source), "html", null, true);
                echo "
              </div>
            ";
            }
            // line 36
            echo "          </div> ";
            // line 37
            echo "        </div> ";
            // line 38
            echo "      ";
        }
        // line 39
        echo "
      ";
        // line 40
        $context["sidebar_width"] = (((twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 40) && twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 40))) ? ("col-lg-3") : ("col-lg-4"));
        // line 41
        echo "
      <div class=\"row\">
        ";
        // line 44
        echo "        ";
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 44)) {
            // line 45
            echo "          ";
            $this->displayBlock('sidebar_first', $context, $blocks);
            // line 50
            echo "        ";
        }
        // line 51
        echo "
        <div class=\"col\">
          <div class=\"it-content__wrapper\">
            ";
        // line 54
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 54), 54, $this->source), "html", null, true);
        echo "
          </div>
        </div> ";
        // line 57
        echo "
        ";
        // line 59
        echo "        ";
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 59)) {
            // line 60
            echo "          ";
            $this->displayBlock('sidebar_second', $context, $blocks);
            // line 65
            echo "        ";
        }
        // line 66
        echo "
      </div> ";
        // line 68
        echo "    </div> ";
        // line 69
        echo "  </main>
 ";
    }

    // line 45
    public function block_sidebar_first($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 46
        echo "            <aside class=\"";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["sidebar_width"] ?? null), 46, $this->source), "html", null, true);
        echo " it-sidebar-first__wrapper\" role=\"complementary\">
              ";
        // line 47
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 47), 47, $this->source), "html", null, true);
        echo "
            </aside>
          ";
    }

    // line 60
    public function block_sidebar_second($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 61
        echo "            <aside class=\"";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["sidebar_width"] ?? null), 61, $this->source), "html", null, true);
        echo " it-sidebar-second__wrapper\" role=\"complementary\">
              ";
        // line 62
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 62), 62, $this->source), "html", null, true);
        echo "
            </aside>
          ";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/layout/content/_partial.content.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  212 => 62,  207 => 61,  203 => 60,  196 => 47,  191 => 46,  187 => 45,  182 => 69,  180 => 68,  177 => 66,  174 => 65,  171 => 60,  168 => 59,  165 => 57,  160 => 54,  155 => 51,  152 => 50,  149 => 45,  146 => 44,  142 => 41,  140 => 40,  137 => 39,  134 => 38,  132 => 37,  130 => 36,  124 => 33,  121 => 32,  119 => 31,  116 => 30,  110 => 27,  107 => 26,  105 => 25,  102 => 24,  96 => 21,  93 => 20,  91 => 19,  88 => 18,  82 => 15,  79 => 14,  77 => 13,  74 => 12,  68 => 9,  65 => 8,  63 => 7,  59 => 5,  57 => 4,  53 => 3,  50 => 2,  42 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/layout/content/_partial.content.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/content/_partial.content.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("block" => 1, "if" => 4, "set" => 40);
        static $filters = array("escape" => 3);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['block', 'if', 'set'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
