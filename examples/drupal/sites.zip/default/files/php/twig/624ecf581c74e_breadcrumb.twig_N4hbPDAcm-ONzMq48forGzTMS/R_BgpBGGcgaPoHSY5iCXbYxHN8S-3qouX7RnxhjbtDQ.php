<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia_components/breadcrumb/breadcrumb.twig */
class __TwigTemplate_baee8fb53341ea3fd71bd64a218b18e033b36b1ccf750a84ad9da0b83bb57311 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 15
        $context["icon_classes"] = [0 => "icon", 1 => "icon-sm", 2 => "align-top", 3 => "mr-1"];
        // line 16
        echo "
";
        // line 17
        if (($context["breadcrumb_dark_background"] ?? null)) {
            // line 18
            echo "  ";
            $context["dark"] = " dark";
            // line 19
            echo "  ";
            $context["icon_classes"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["icon_classes"] ?? null), 19, $this->source), [0 => "icon-white"]);
        }
        // line 21
        echo "
<nav class=\"breadcrumb-container\" aria-label=\"breadcrumb\">
  <ol class=\"breadcrumb";
        // line 23
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["dark"] ?? null), 23, $this->source), "html", null, true);
        echo "\">
    ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["breadcrumb"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 25
            echo "      ";
            if (twig_get_attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, true, 25)) {
                // line 26
                echo "        <li class=\"breadcrumb-item\">
          ";
                // line 27
                ob_start(function () { return ''; });
                // line 28
                echo "            ";
                if (($context["breadcrumb_image"] ?? null)) {
                    // line 29
                    echo "              ";
                    $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia_components/breadcrumb/breadcrumb.twig", 29)->display(twig_array_merge($context, ["name" => "it-link", "classes" => [0 =>                     // line 31
($context["icon_classes"] ?? null)]]));
                    // line 33
                    echo "            ";
                }
                // line 34
                echo "            <a href=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, true, 34), 34, $this->source), "html", null, true);
                echo "\">";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "text", [], "any", false, false, true, 34), 34, $this->source), "html", null, true);
                echo "</a>
            ";
                // line 35
                if ((($context["breadcrumb_separator"] ?? null) && (twig_get_attribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, true, 35) == false))) {
                    // line 36
                    echo "              <span class=\"separator\">";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["breadcrumb_separator"] ?? null), 36, $this->source), "html", null, true);
                    echo "</span>
            ";
                }
                // line 38
                echo "          ";
                echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
                // line 39
                echo "        </li>
      ";
            } else {
                // line 41
                echo "        <li class=\"breadcrumb-item active\" aria-current=\"page\">";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "text", [], "any", false, false, true, 41), 41, $this->source), "html", null, true);
                echo "
          ";
                // line 42
                if ((($context["breadcrumb_separator"] ?? null) && (twig_get_attribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, true, 42) == false))) {
                    // line 43
                    echo "            <span class=\"separator\">";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["breadcrumb_separator"] ?? null), 43, $this->source), "html", null, true);
                    echo "</span>
          ";
                }
                // line 45
                echo "        </li>
      ";
            }
            // line 47
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "  </ol>
</nav>
";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia_components/breadcrumb/breadcrumb.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 48,  135 => 47,  131 => 45,  125 => 43,  123 => 42,  118 => 41,  114 => 39,  111 => 38,  105 => 36,  103 => 35,  96 => 34,  93 => 33,  91 => 31,  89 => 29,  86 => 28,  84 => 27,  81 => 26,  78 => 25,  61 => 24,  57 => 23,  53 => 21,  49 => 19,  46 => 18,  44 => 17,  41 => 16,  39 => 15,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia_components/breadcrumb/breadcrumb.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/src/components/breadcrumb/breadcrumb.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 15, "if" => 17, "for" => 24, "spaceless" => 27, "include" => 29);
        static $filters = array("merge" => 19, "escape" => 23);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'for', 'spaceless', 'include'],
                ['merge', 'escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
