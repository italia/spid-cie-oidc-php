<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia_components/social/social.twig */
class __TwigTemplate_1350e386f9e31c66a8278ad06841f23f11e16ec507af0fec06fcfeb2c3f5f4d5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        if (($context["socials"] ?? null)) {
            // line 13
            echo "  <div class=\"it-socials d-none d-md-flex\">
    <span>";
            // line 14
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Seguici su"));
            echo "</span>
    <ul>
      ";
            // line 16
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["socials"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["social"]) {
                // line 17
                echo "        ";
                if (twig_get_attribute($this->env, $this->source, $context["social"], "url", [], "any", false, false, true, 17)) {
                    // line 18
                    echo "          <li>
            <a aria-label=\"";
                    // line 19
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["social"], "label", [], "any", false, false, true, 19), 19, $this->source), "html", null, true);
                    echo "\" href=\"";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["social"], "url", [], "any", false, false, true, 19), 19, $this->source), "html", null, true);
                    echo "\" target=\"_blank\">
              ";
                    // line 20
                    $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia_components/social/social.twig", 20)->display(twig_array_merge($context, ["name" => ("it-" . twig_lower_filter($this->env, twig_get_attribute($this->env, $this->source, $context["social"], "label", [], "any", false, false, true, 20)))]));
                    // line 21
                    echo "            </a>
          </li>
        ";
                }
                // line 24
                echo "      ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['social'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "    </ul>
  </div>
";
        }
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia_components/social/social.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 25,  85 => 24,  80 => 21,  78 => 20,  72 => 19,  69 => 18,  66 => 17,  49 => 16,  44 => 14,  41 => 13,  39 => 12,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia_components/social/social.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/src/components/social/social.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 12, "for" => 16, "include" => 20);
        static $filters = array("t" => 14, "escape" => 19, "lower" => 20);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'for', 'include'],
                ['t', 'escape', 'lower'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
