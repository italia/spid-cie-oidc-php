<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/macros.twig */
class __TwigTemplate_b6faea1db2fa08432d74bb738ef43db00902a28ae2974b1b65ee803f6bb6cbaf extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 9
        echo "
";
    }

    // line 1
    public function macro_icon($__icon_name__ = null, $__active_theme_path__ = null, $__classes__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "icon_name" => $__icon_name__,
            "active_theme_path" => $__active_theme_path__,
            "classes" => $__classes__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start(function () { return ''; });
        try {
            // line 2
            echo "  <svg class=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, _twig_default_filter(twig_join_filter($this->sandbox->ensureToStringAllowed(($context["classes"] ?? null), 2, $this->source), " "), "icon"), "html", null, true);
            echo "\">
    <use xlink:href=\"";
            // line 3
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["active_theme_path"] ?? null), 3, $this->source), "html", null, true);
            echo "/assets/svg/sprite.svg#";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["icon_name"] ?? null), 3, $this->source), "html", null, true);
            echo "\"></use>
  </svg>
  <script>
    console.error('macro.icon is deprecated, use icon component! See: bootstrap_italia/src/components/icon');
  </script>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 10
    public function macro_password_icon($__active_theme_path__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "active_theme_path" => $__active_theme_path__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start(function () { return ''; });
        try {
            // line 11
            echo "  <span class=\"password-icon\" aria-hidden=\"true\">
    <svg class=\"password-icon-visible icon icon-sm\">
      <use xlink:href=\"";
            // line 13
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["active_theme_path"] ?? null), 13, $this->source), "html", null, true);
            echo "/assets/svg/sprite.svg#it-password-visible\"></use>
    </svg>
    <svg class=\"password-icon-invisible icon icon-sm d-none\">
      <use xlink:href=\"";
            // line 16
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["active_theme_path"] ?? null), 16, $this->source), "html", null, true);
            echo "/assets/svg/sprite.svg#it-password-invisible\"></use>
    </svg>
  </span>
  <script>
    console.error('macro.password_icon is deprecated, use password_icon component! See: bootstrap_italia/src/components/password_icon');
  </script>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/macros.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 16,  98 => 13,  94 => 11,  81 => 10,  64 => 3,  59 => 2,  44 => 1,  39 => 9,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/macros.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/macros.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("macro" => 1);
        static $filters = array("escape" => 2, "default" => 2, "join" => 2);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['macro'],
                ['escape', 'default', 'join'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
