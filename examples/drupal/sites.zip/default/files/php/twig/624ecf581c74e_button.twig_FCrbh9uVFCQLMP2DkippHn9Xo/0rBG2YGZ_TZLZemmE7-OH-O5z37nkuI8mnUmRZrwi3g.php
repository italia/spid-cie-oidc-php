<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia_components/button/button.twig */
class __TwigTemplate_8163cd11602c90fb6fffc993b51f2d8c46275e93590568359c1d2ec6a71aae1d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 23
        $context["button_classes"] = [0 => "btn", 1 => ((        // line 25
($context["type"] ?? null)) ? (("btn-" . $this->sandbox->ensureToStringAllowed(($context["type"] ?? null), 25, $this->source))) : ("")), 2 => ((        // line 26
($context["size"] ?? null)) ? (("btn-" . $this->sandbox->ensureToStringAllowed(($context["size"] ?? null), 26, $this->source))) : ("")), 3 => ((        // line 27
($context["outline"] ?? null)) ? (("btn-" . $this->sandbox->ensureToStringAllowed(($context["outline"] ?? null), 27, $this->source))) : ("")), 4 => ((        // line 28
($context["icon"] ?? null)) ? (("btn-" . $this->sandbox->ensureToStringAllowed(($context["icon"] ?? null), 28, $this->source))) : ("")), 5 => ((        // line 29
($context["block"] ?? null)) ? ("btn-block") : (""))];
        // line 31
        if (($context["classes"] ?? null)) {
            // line 32
            echo "  ";
            $context["button_classes"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["button_classes"] ?? null), 32, $this->source), $this->sandbox->ensureToStringAllowed(($context["classes"] ?? null), 32, $this->source));
        }
        // line 34
        $context["dt"] = "";
        // line 35
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["data_attributes"] ?? null));
        foreach ($context['_seq'] as $context["data"] => $context["attribute"]) {
            // line 36
            echo "  ";
            $context["dt"] = ((((($this->sandbox->ensureToStringAllowed(($context["dt"] ?? null), 36, $this->source) . "data-") . $this->sandbox->ensureToStringAllowed($context["data"], 36, $this->source)) . "=\"") . $this->sandbox->ensureToStringAllowed($context["attribute"], 36, $this->source)) . "\" ");
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['data'], $context['attribute'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "
";
        // line 39
        if ((($context["tag"] ?? null) == "input")) {
            // line 40
            echo "  <input";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => ($context["button_classes"] ?? null)], "method", false, false, true, 40), 40, $this->source), "html", null, true);
            echo "
  ";
            // line 41
            if (($context["input_type"] ?? null)) {
                // line 42
                echo "  type=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["input_type"] ?? null), 42, $this->source), "html", null, true);
                echo "\"
  ";
            }
            // line 44
            echo "  ";
            if (($context["value"] ?? null)) {
                // line 45
                echo "  value=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["value"] ?? null), 45, $this->source), "html", null, true);
                echo "\"
  ";
            }
            // line 46
            echo " />
";
        } else {
            // line 48
            echo "  <";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["tag"] ?? null), 48, $this->source), "html", null, true);
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => ($context["button_classes"] ?? null)], "method", false, false, true, 48), 48, $this->source), "html", null, true);
            echo " ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(twig_trim_filter($this->sandbox->ensureToStringAllowed(($context["dt"] ?? null), 48, $this->source)));
            if ((($context["tag"] ?? null) == "a")) {
                echo " href=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["href"] ?? null), 48, $this->source), "html", null, true);
                echo "\" role=\"button\"";
            }
            // line 49
            echo "  >";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["value"] ?? null), 49, $this->source), "html", null, true);
            echo "</";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["tag"] ?? null), 49, $this->source), "html", null, true);
            echo ">
";
        }
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia_components/button/button.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 49,  96 => 48,  92 => 46,  86 => 45,  83 => 44,  77 => 42,  75 => 41,  70 => 40,  68 => 39,  65 => 38,  58 => 36,  54 => 35,  52 => 34,  48 => 32,  46 => 31,  44 => 29,  43 => 28,  42 => 27,  41 => 26,  40 => 25,  39 => 23,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia_components/button/button.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/src/components/button/button.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 23, "if" => 31, "for" => 35);
        static $filters = array("merge" => 32, "escape" => 40, "raw" => 48, "trim" => 48);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'for'],
                ['merge', 'escape', 'raw', 'trim'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
