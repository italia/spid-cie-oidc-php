<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/layout/pages/page--user--register.html.twig */
class __TwigTemplate_faf3b55b7c7435fc501279de36ec2ac5721ab22ffc180bb46c4245247f6e7728 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 36
        echo "<div id=\"page-user-login\">
  ";
        // line 37
        $this->displayBlock('main', $context, $blocks);
        // line 81
        echo "</div>
";
    }

    // line 37
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 38
        echo "    <main>
      <div role=\"main\" class=\"container main-container js-quickedit-main-content\">
        ";
        // line 40
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "brand", [], "any", false, false, true, 40)) {
            // line 41
            echo "          <div class=\"row justify-content-center\">
              <div class=\"col-auto p-4\">
                ";
            // line 43
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "brand", [], "any", false, false, true, 43), 43, $this->source), "html", null, true);
            echo "
              </div>
          </div>
        ";
        }
        // line 47
        echo "        <div class=\"login-box row justify-content-center\">
          <div class=\"col-md-auto p-5 mb-5\">
            ";
        // line 49
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "title", [], "any", false, false, true, 49)) {
            // line 50
            echo "              <div class=\"it-page-title-wrapper\" class=\"sr-only\">
                ";
            // line 51
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "title", [], "any", false, false, true, 51), 51, $this->source), "html", null, true);
            echo "
              </div>
            ";
        }
        // line 54
        echo "
            ";
        // line 55
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "local_tasks", [], "any", false, false, true, 55)) {
            // line 56
            echo "              <div class=\"it-local-tasks-wrapper\">
                ";
            // line 57
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "local_tasks", [], "any", false, false, true, 57), 57, $this->source), "html", null, true);
            echo "
              </div>
            ";
        }
        // line 60
        echo "
            ";
        // line 61
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 61)) {
            // line 62
            echo "              <div class=\"it-help-wrapper\">
                ";
            // line 63
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "help", [], "any", false, false, true, 63), 63, $this->source), "html", null, true);
            echo "
              </div>
            ";
        }
        // line 66
        echo "
            ";
        // line 67
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "notification", [], "any", false, false, true, 67)) {
            // line 68
            echo "              <div class=\"it-notification-wrapper\">
                ";
            // line 69
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "notification", [], "any", false, false, true, 69), 69, $this->source), "html", null, true);
            echo "
              </div>
            ";
        }
        // line 72
        echo "
            <div class=\"it-content-wrapper mt-5\">
              ";
        // line 74
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 74), 74, $this->source), "html", null, true);
        echo "
            </div>
          </div> ";
        // line 77
        echo "        </div> ";
        // line 78
        echo "      </div> ";
        // line 79
        echo "    </main>
  ";
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/layout/pages/page--user--register.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  141 => 79,  139 => 78,  137 => 77,  132 => 74,  128 => 72,  122 => 69,  119 => 68,  117 => 67,  114 => 66,  108 => 63,  105 => 62,  103 => 61,  100 => 60,  94 => 57,  91 => 56,  89 => 55,  86 => 54,  80 => 51,  77 => 50,  75 => 49,  71 => 47,  64 => 43,  60 => 41,  58 => 40,  54 => 38,  50 => 37,  45 => 81,  43 => 37,  40 => 36,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/layout/pages/page--user--register.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/pages/page--user--register.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("block" => 37, "if" => 40);
        static $filters = array("escape" => 43);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['block', 'if'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
