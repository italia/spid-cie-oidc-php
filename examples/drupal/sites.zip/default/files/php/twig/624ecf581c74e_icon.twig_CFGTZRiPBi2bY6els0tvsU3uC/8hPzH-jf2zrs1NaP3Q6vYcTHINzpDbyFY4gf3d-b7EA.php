<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia_components/icon/icon.twig */
class __TwigTemplate_1dbb3968b20bec3b9b6dd38214507b64b632e65da59065d8ea4ec5d874e732f3 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 27
        ob_start(function () { return ''; });
        // line 28
        $context["icon_classes"] = [0 => "icon", 1 => ((        // line 30
($context["size"] ?? null)) ? (("icon-" . $this->sandbox->ensureToStringAllowed(($context["size"] ?? null), 30, $this->source))) : ("")), 2 => ((        // line 31
($context["color"] ?? null)) ? (("icon-" . $this->sandbox->ensureToStringAllowed(($context["color"] ?? null), 31, $this->source))) : ("")), 3 => ((        // line 32
($context["dark"] ?? null)) ? ("bg-dark") : ("")), 4 => ((        // line 33
($context["light"] ?? null)) ? ("bg-light") : ("")), 5 => ((        // line 34
($context["padded"] ?? null)) ? ("icon-padded") : ("")), 6 => ((        // line 35
($context["alignment"] ?? null)) ? (("align-" . $this->sandbox->ensureToStringAllowed(($context["alignment"] ?? null), 35, $this->source))) : (""))];
        // line 38
        echo "
";
        // line 39
        if (array_key_exists("classes", $context)) {
            // line 40
            echo "  ";
            $context["icon_classes"] = twig_array_merge($this->sandbox->ensureToStringAllowed(($context["classes"] ?? null), 40, $this->source), $this->sandbox->ensureToStringAllowed(($context["icon_classes"] ?? null), 40, $this->source));
        }
        // line 42
        echo "
";
        // line 43
        $context["library"] = ((($context["library"] ?? null)) ? (($context["library"] ?? null)) : ("sprite.svg"));
        // line 44
        echo "
<svg class=\"";
        // line 45
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_trim_filter(twig_join_filter($this->sandbox->ensureToStringAllowed(($context["icon_classes"] ?? null), 45, $this->source), " ")), "html", null, true);
        echo "\">
  <use
    href=\"/";
        // line 47
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getActiveThemePath(), "html", null, true);
        echo "/assets/svg/";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["library"] ?? null), 47, $this->source), "html", null, true);
        echo "#";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["name"] ?? null), 47, $this->source), "html", null, true);
        echo "\"
    xlink:href=\"/";
        // line 48
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getActiveThemePath(), "html", null, true);
        echo "/assets/svg/";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["library"] ?? null), 48, $this->source), "html", null, true);
        echo "#";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["name"] ?? null), 48, $this->source), "html", null, true);
        echo "\"
  ></use>
</svg>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia_components/icon/icon.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 48,  71 => 47,  66 => 45,  63 => 44,  61 => 43,  58 => 42,  54 => 40,  52 => 39,  49 => 38,  47 => 35,  46 => 34,  45 => 33,  44 => 32,  43 => 31,  42 => 30,  41 => 28,  39 => 27,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia_components/icon/icon.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/src/components/icon/icon.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("spaceless" => 27, "set" => 28, "if" => 39);
        static $filters = array("merge" => 40, "escape" => 45, "trim" => 45, "join" => 45);
        static $functions = array("active_theme_path" => 47);

        try {
            $this->sandbox->checkSecurity(
                ['spaceless', 'set', 'if'],
                ['merge', 'escape', 'trim', 'join'],
                ['active_theme_path']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
