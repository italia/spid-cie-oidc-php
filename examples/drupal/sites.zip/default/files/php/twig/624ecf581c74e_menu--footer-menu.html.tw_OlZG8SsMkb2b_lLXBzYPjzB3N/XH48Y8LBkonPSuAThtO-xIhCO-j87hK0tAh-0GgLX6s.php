<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/navigation/footer/menu--footer-menu.html.twig */
class __TwigTemplate_9206ccf581a9a28007f79de16646c5af01392453932651f7b29948d0bfbdb2e5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 21
        echo "<div class=\"row\">
  ";
        // line 22
        $context["col"] = (((twig_length_filter($this->env, $this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 22, $this->source)) > 4)) ? (3) : ((12 / twig_length_filter($this->env, $this->sandbox->ensureToStringAllowed(($context["items"] ?? null), 22, $this->source)))));
        // line 23
        echo "  ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["items"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 24
            echo "    <div class=\"col-lg-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["col"] ?? null), 24, $this->source), "html", null, true);
            echo " col-md-";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["col"] ?? null), 24, $this->source), "html", null, true);
            echo " col-sm-6 pb-2\">
      <h4>";
            // line 25
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getLink($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 25), 25, $this->source), $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, true, 25), 25, $this->source)), "html", null, true);
            echo "</h4>
      <div class=\"link-list-wrapper\">
        ";
            // line 27
            if (twig_get_attribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 27)) {
                // line 28
                echo "        <ul";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => [0 => "footer-list", 1 => "link-list", 2 => "clearfix"]], "method", false, false, true, 28), 28, $this->source), "html", null, true);
                echo ">
          ";
                // line 29
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 29));
                foreach ($context['_seq'] as $context["_key"] => $context["item_second"]) {
                    // line 30
                    echo "            ";
                    if ((twig_get_attribute($this->env, $this->source, $context["item_second"], "title", [], "any", false, false, true, 30) == "<divider>")) {
                        // line 31
                        echo "              <span class=\"divider\"></span>
            ";
                    } else {
                        // line 33
                        echo "              <li";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item_second"], "attributes", [], "any", false, false, true, 33), 33, $this->source), "html", null, true);
                        echo ">
                ";
                        // line 34
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->getLink($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item_second"], "title", [], "any", false, false, true, 34), 34, $this->source), $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item_second"], "url", [], "any", false, false, true, 34), 34, $this->source)), "html", null, true);
                        echo "
              </li>
            ";
                    }
                    // line 37
                    echo "          ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item_second'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 38
                echo "        </ul>
        ";
            }
            // line 40
            echo "      </div>
    </div>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/navigation/footer/menu--footer-menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 43,  100 => 40,  96 => 38,  90 => 37,  84 => 34,  79 => 33,  75 => 31,  72 => 30,  68 => 29,  63 => 28,  61 => 27,  56 => 25,  49 => 24,  44 => 23,  42 => 22,  39 => 21,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/navigation/footer/menu--footer-menu.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/navigation/footer/menu--footer-menu.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 22, "for" => 23, "if" => 27);
        static $filters = array("length" => 22, "escape" => 24);
        static $functions = array("link" => 25);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'for', 'if'],
                ['length', 'escape'],
                ['link']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
