<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/layout/header/_partial.header-slim.html.twig */
class __TwigTemplate_ff4257e1d6ac660146aac966727d4afb2015781cff2035346ba33651fde6a00b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'headerSlim' => [$this, 'block_headerSlim'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        $this->displayBlock('headerSlim', $context, $blocks);
    }

    public function block_headerSlim($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "  <div class=\"it-header-slim-wrapper";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["slim_header_light"] ?? null)) ? (" theme-light") : ("")));
        echo "\">
    <div class=\"";
        // line 3
        ((($context["slim_header_container_type"] ?? null)) ? (print ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["slim_header_container_type"] ?? null), "html", null, true))) : (print ("container")));
        echo "\">
      <div class=\"row\">
        <div class=\"col-12\">
          <div class=\"it-header-slim-wrapper-content\">
            <a class=\"d-none d-lg-block navbar-brand\" href=\"";
        // line 7
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["ente_appartenenza_url"] ?? null), 7, $this->source), "html", null, true);
        echo "\" target=\"_blank\">";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["ente_appartenenza_nome"] ?? null), 7, $this->source), "html", null, true);
        echo "</a>
            <div class=\"nav-mobile\">
              <nav>
                ";
        // line 10
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_slim_menu", [], "any", false, false, true, 10)) {
            // line 11
            echo "                  <a class=\"it-opener d-lg-none\" data-toggle=\"collapse\" href=\"#slim-menu-collapsed-breakpoint\" role=\"button\" aria-expanded=\"false\" aria-controls=\"slim-menu-collapsed-breakpoint\">
                    <span>";
            // line 12
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["ente_appartenenza_nome"] ?? null), 12, $this->source), "html", null, true);
            echo "</span>
                    ";
            // line 13
            $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia/layout/header/_partial.header-slim.html.twig", 13)->display(twig_array_merge($context, ["name" => "it-expand"]));
            // line 14
            echo "                  </a>
                  <div class=\"link-list-wrapper collapse\" id=\"slim-menu-collapsed-breakpoint\">
                    ";
            // line 16
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_slim_menu", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
            echo "
                  </div>
                ";
        } else {
            // line 19
            echo "                  <a class=\"d-lg-none navbar-brand\" href=\"";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["ente_appartenenza_url"] ?? null), 19, $this->source), "html", null, true);
            echo "\" target=\"_blank\">";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["ente_appartenenza_nome"] ?? null), 19, $this->source), "html", null, true);
            echo "</a>
                ";
        }
        // line 21
        echo "              </nav>
            </div>
            <div class=\"it-header-slim-right-zone\">
              ";
        // line 24
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_slim_lingua", [], "any", false, false, true, 24)) {
            // line 25
            echo "                ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_slim_lingua", [], "any", false, false, true, 25), 25, $this->source), "html", null, true);
            echo "
              ";
        }
        // line 27
        echo "              ";
        if (($context["logged_in"] ?? null)) {
            // line 28
            echo "                ";
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_slim_action", [], "any", false, false, true, 28)) {
                // line 29
                echo "                  ";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_slim_action", [], "any", false, false, true, 29), 29, $this->source), "html", null, true);
                echo "
                ";
            }
            // line 31
            echo "              ";
        } else {
            // line 32
            echo "                ";
            if ((($context["right_action_size"] ?? null) == "normal")) {
                // line 33
                echo "                <div class=\"it-access-top-wrapper\">
                  <a class=\"btn btn-primary btn-sm btn-icon\" href=\"";
                // line 34
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["base_path"] ?? null), 34, $this->source), "html", null, true);
                echo "user\">
                    ";
                // line 35
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Log in"));
                echo "</a>
                </div>
                ";
            } elseif ((            // line 37
($context["right_action_size"] ?? null) == "full")) {
                // line 38
                echo "                  <a href=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["base_path"] ?? null), 38, $this->source), "html", null, true);
                echo "user\" class=\"btn btn-primary btn-icon btn-full\">
                    <span class=\"rounded-icon\">
                      ";
                // line 40
                $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia/layout/header/_partial.header-slim.html.twig", 40)->display(twig_array_merge($context, ["name" => "it-user", "classes" => [0 => "icon-primary"]]));
                // line 44
                echo "                    </span>
                    <span class=\"d-none d-lg-block\">";
                // line 45
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Accedi all'area personale"));
                echo "</span>
                  </a>
                ";
            }
            // line 48
            echo "              ";
        }
        // line 49
        echo "            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/layout/header/_partial.header-slim.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  161 => 49,  158 => 48,  152 => 45,  149 => 44,  147 => 40,  141 => 38,  139 => 37,  134 => 35,  130 => 34,  127 => 33,  124 => 32,  121 => 31,  115 => 29,  112 => 28,  109 => 27,  103 => 25,  101 => 24,  96 => 21,  88 => 19,  82 => 16,  78 => 14,  76 => 13,  72 => 12,  69 => 11,  67 => 10,  59 => 7,  52 => 3,  47 => 2,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/layout/header/_partial.header-slim.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/header/_partial.header-slim.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("block" => 1, "if" => 10, "include" => 13);
        static $filters = array("escape" => 3, "trans" => 35);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['block', 'if', 'include'],
                ['escape', 'trans'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
