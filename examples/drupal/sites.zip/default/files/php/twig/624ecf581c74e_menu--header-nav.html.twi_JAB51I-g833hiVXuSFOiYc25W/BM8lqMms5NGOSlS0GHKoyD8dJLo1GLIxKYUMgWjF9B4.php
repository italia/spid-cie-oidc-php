<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-nav.html.twig */
class __TwigTemplate_560483815f250f8b0dc0e610eba621388aea5d06df60ba564ca96594896a5c2c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 27
        echo "<ul";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => "navbar-nav"], "method", false, false, true, 27), 27, $this->source), "html", null, true);
        echo ">
  ";
        // line 29
        echo "  ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["items"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 30
            echo "
    ";
            // line 32
            echo "    ";
            $context["megamenu"] = false;
            // line 33
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 33));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 34
                echo "      ";
                // line 35
                echo "      ";
                if ((($context["megamenu"] ?? null) == false)) {
                    // line 36
                    echo "        ";
                    $context["megamenu"] = ((twig_get_attribute($this->env, $this->source, $context["i"], "is_expanded", [], "any", false, false, true, 36)) ? (true) : (""));
                    // line 37
                    echo "      ";
                }
                // line 38
                echo "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 39
            echo "
    ";
            // line 42
            echo "    ";
            // line 43
            $context["container_list_classes"] = [0 => "nav-item", 1 => ((twig_get_attribute($this->env, $this->source,             // line 45
$context["item"], "is_expanded", [], "any", false, false, true, 45)) ? ("dropdown") : ("")), 2 => ((twig_get_attribute($this->env, $this->source,             // line 46
$context["item"], "is_collapsed", [], "any", false, false, true, 46)) ? ("collapsed") : ("")), 3 => ((twig_get_attribute($this->env, $this->source,             // line 47
$context["item"], "in_active_trail", [], "any", false, false, true, 47)) ? ("active") : ("")), 4 => ((            // line 48
($context["megamenu"] ?? null)) ? ("megamenu") : (""))];
            // line 51
            echo "
    ";
            // line 54
            echo "    ";
            // line 55
            $context["container_link_classes"] = [0 => "nav-link", 1 => ((twig_get_attribute($this->env, $this->source,             // line 57
$context["item"], "is_expanded", [], "any", false, false, true, 57)) ? ("dropdown-toggle") : ("")), 2 => ((twig_get_attribute($this->env, $this->source,             // line 58
$context["item"], "is_collapsed", [], "any", false, false, true, 58)) ? ("collapsed") : ("")), 3 => ((twig_get_attribute($this->env, $this->source,             // line 59
$context["item"], "in_active_trail", [], "any", false, false, true, 59)) ? ("active") : (""))];
            // line 62
            echo "    <li";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "attributes", [], "any", false, false, true, 62), "addClass", [0 => ($context["container_list_classes"] ?? null)], "method", false, false, true, 62), 62, $this->source), "html", null, true);
            echo ">
      <a
        class=\"";
            // line 64
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["container_link_classes"] ?? null), 64, $this->source), " "), "html", null, true);
            echo "\"
        ";
            // line 65
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((twig_get_attribute($this->env, $this->source, $context["item"], "is_expanded", [], "any", false, false, true, 65)) ? ("data-toggle=\"dropdown\" aria-expanded=\"false\"") : ("")));
            echo "
        href=\"";
            // line 66
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, true, 66), 66, $this->source), "html", null, true);
            echo "\"
        ";
            // line 67
            if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "original_link", [], "any", false, false, true, 67), "getDescription", [], "method", false, false, true, 67)) {
                // line 68
                echo "          title=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "original_link", [], "any", false, false, true, 68), "getDescription", [], "method", false, false, true, 68), 68, $this->source), "html", null, true);
                echo "\"
        ";
            }
            // line 70
            echo "      >
        <span>";
            // line 71
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 71), 71, $this->source), "html", null, true);
            echo "</span>

        ";
            // line 74
            echo "        ";
            if (twig_get_attribute($this->env, $this->source, $context["item"], "is_expanded", [], "any", false, false, true, 74)) {
                // line 75
                echo "          ";
                $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-nav.html.twig", 75)->display(twig_array_merge($context, ["name" => "it-expand"]));
                // line 76
                echo "        ";
            }
            // line 77
            echo "      </a>

      ";
            // line 80
            echo "      ";
            if (twig_get_attribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 80)) {
                // line 81
                echo "        <div class=\"dropdown-menu\">

          ";
                // line 84
                echo "          ";
                if ((($context["megamenu"] ?? null) == false)) {
                    // line 85
                    echo "            ";
                    $this->loadTemplate("@bootstrap_italia_components/link-list/menu-recursive.twig", "themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-nav.html.twig", 85)->display(twig_array_merge($context, ["menu_name" =>                     // line 86
($context["menu_name"] ?? null), "items" => twig_get_attribute($this->env, $this->source,                     // line 87
$context["item"], "below", [], "any", false, false, true, 87), "attributes" =>                     // line 88
($context["attributes"] ?? null), "view_link_description" =>                     // line 89
($context["main_menu_dropdown_link_description"] ?? null), "large" =>                     // line 90
($context["main_menu_link_size"] ?? null), "bold" => false, "icon_position" => "right", "icon_type" => "it-expand", "icon_color" => "primary", "active_items_large" => false, "active_items_bold" =>                     // line 96
($context["main_menu_link_bolder_active"] ?? null)]));
                    // line 98
                    echo "          ";
                } else {
                    echo " ";
                    // line 99
                    echo "            ";
                    // line 100
                    echo "            <div class=\"row\">
              ";
                    // line 101
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 101));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["m_items"]) {
                        // line 102
                        echo "                <div class=\"col-xs-12 col-lg\"> ";
                        // line 103
                        echo "                  <div class=\"link-list-wrapper\">
                    <ul class=\"link-list\">
                      ";
                        // line 106
                        $context["list_classes_second_level"] = [0 => ((twig_get_attribute($this->env, $this->source,                         // line 107
$context["m_items"], "is_expanded", [], "any", false, false, true, 107)) ? ("expanded") : ("")), 1 => ((twig_get_attribute($this->env, $this->source,                         // line 108
$context["m_items"], "is_collapsed", [], "any", false, false, true, 108)) ? ("collapsed") : ("")), 2 => ((twig_get_attribute($this->env, $this->source,                         // line 109
$context["m_items"], "in_active_trail", [], "any", false, false, true, 109)) ? ("active") : ("")), 3 => ((twig_get_attribute($this->env, $this->source,                         // line 110
$context["m_items"], "below", [], "any", false, false, true, 110)) ? ("dropdown") : (""))];
                        // line 113
                        echo "                      ";
                        // line 114
                        $context["link_classes_second_level"] = [0 => "list-item", 1 => ((twig_get_attribute($this->env, $this->source,                         // line 116
$context["m_items"], "is_expanded", [], "any", false, false, true, 116)) ? ("expanded") : ("")), 2 => ((twig_get_attribute($this->env, $this->source,                         // line 117
$context["m_items"], "is_collapsed", [], "any", false, false, true, 117)) ? ("collapsed") : ("")), 3 => ((twig_get_attribute($this->env, $this->source,                         // line 118
$context["m_items"], "in_active_trail", [], "any", false, false, true, 118)) ? ("active") : ("")), 4 => ((                        // line 119
($context["main_menu_link_size"] ?? null)) ? ("large") : ("")), 5 => ((                        // line 120
($context["main_menu_link_bolder_active"] ?? null)) ? ("medium") : (""))];
                        // line 123
                        echo "
                      ";
                        // line 125
                        echo "                      ";
                        if ((twig_get_attribute($this->env, $this->source, $context["m_items"], "title", [], "any", false, false, true, 125) != "<hide>")) {
                            // line 126
                            echo "                        <li>
                          <h3 class=\"no_toc\">
                            ";
                            // line 128
                            if (twig_test_empty(twig_get_attribute($this->env, $this->source, $context["m_items"], "url", [], "any", false, false, true, 128))) {
                                // line 129
                                echo "                              <a
                                class=\"";
                                // line 130
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_join_filter($this->sandbox->ensureToStringAllowed(($context["link_classes_second_level"] ?? null), 130, $this->source), " "), "html", null, true);
                                echo " pl-0\"
                                ";
                                // line 131
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["m_items"], "attributes", [], "any", false, false, true, 131), 131, $this->source), "html", null, true);
                                echo "
                                href=\"";
                                // line 132
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["m_items"], "url", [], "any", false, false, true, 132), 132, $this->source), "html", null, true);
                                echo "\"
                                ";
                                // line 133
                                if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["m_items"], "original_link", [], "any", false, false, true, 133), "getDescription", [], "method", false, false, true, 133)) {
                                    // line 134
                                    echo "                                  title=\"";
                                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["m_items"], "original_link", [], "any", false, false, true, 134), "getDescription", [], "method", false, false, true, 134), 134, $this->source), "html", null, true);
                                    echo "\"
                                ";
                                }
                                // line 136
                                echo "                              >
                            ";
                            }
                            // line 138
                            echo "
                              <span>";
                            // line 139
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["m_items"], "title", [], "any", false, false, true, 139), 139, $this->source), "html", null, true);
                            echo "</span>
                              ";
                            // line 140
                            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["m_items"], "original_link", [], "any", false, false, true, 140), "getDescription", [], "method", false, false, true, 140) && ($context["main_menu_megamenu_title_description"] ?? null))) {
                                // line 141
                                echo "                                <p>";
                                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["m_items"], "original_link", [], "any", false, false, true, 141), "getDescription", [], "method", false, false, true, 141), 141, $this->source), "html", null, true);
                                echo "</p>
                              ";
                            }
                            // line 143
                            echo "
                            ";
                            // line 144
                            if (twig_test_empty(twig_get_attribute($this->env, $this->source, $context["m_items"], "url", [], "any", false, false, true, 144))) {
                                // line 145
                                echo "                              </a>
                            ";
                            }
                            // line 147
                            echo "                          </h3>
                        </li>
                      ";
                        }
                        // line 149
                        echo " ";
                        // line 150
                        echo "                      ";
                        $this->loadTemplate("@bootstrap_italia_components/link-list/menu-recursive.twig", "themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-nav.html.twig", 150)->display(twig_array_merge($context, ["menu_name" =>                         // line 151
($context["menu_name"] ?? null), "items" => twig_get_attribute($this->env, $this->source,                         // line 152
$context["m_items"], "below", [], "any", false, false, true, 152), "attributes" =>                         // line 153
($context["attributes"] ?? null), "view_link_description" =>                         // line 154
($context["main_menu_megamenu_link_description"] ?? null), "large" =>                         // line 155
($context["main_menu_link_size"] ?? null), "bold" => false, "icon_position" => "right", "icon_type" => "it-expand", "icon_color" => "primary", "active_items_large" => false, "active_items_bold" =>                         // line 161
($context["main_menu_link_bolder_active"] ?? null)]));
                        // line 163
                        echo "                    </ul>
                  </div>
                </div>
              ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m_items'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 166
                    echo " ";
                    // line 167
                    echo "            </div>
          ";
                }
                // line 168
                echo " ";
                // line 169
                echo "        </div>
      ";
            }
            // line 170
            echo " ";
            // line 171
            echo "    </li>
  ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 172
        echo " ";
        // line 173
        echo "</ul>
";
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-nav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  351 => 173,  349 => 172,  334 => 171,  332 => 170,  328 => 169,  326 => 168,  322 => 167,  320 => 166,  303 => 163,  301 => 161,  300 => 155,  299 => 154,  298 => 153,  297 => 152,  296 => 151,  294 => 150,  292 => 149,  287 => 147,  283 => 145,  281 => 144,  278 => 143,  272 => 141,  270 => 140,  266 => 139,  263 => 138,  259 => 136,  253 => 134,  251 => 133,  247 => 132,  243 => 131,  239 => 130,  236 => 129,  234 => 128,  230 => 126,  227 => 125,  224 => 123,  222 => 120,  221 => 119,  220 => 118,  219 => 117,  218 => 116,  217 => 114,  215 => 113,  213 => 110,  212 => 109,  211 => 108,  210 => 107,  209 => 106,  205 => 103,  203 => 102,  186 => 101,  183 => 100,  181 => 99,  177 => 98,  175 => 96,  174 => 90,  173 => 89,  172 => 88,  171 => 87,  170 => 86,  168 => 85,  165 => 84,  161 => 81,  158 => 80,  154 => 77,  151 => 76,  148 => 75,  145 => 74,  140 => 71,  137 => 70,  131 => 68,  129 => 67,  125 => 66,  121 => 65,  117 => 64,  111 => 62,  109 => 59,  108 => 58,  107 => 57,  106 => 55,  104 => 54,  101 => 51,  99 => 48,  98 => 47,  97 => 46,  96 => 45,  95 => 43,  93 => 42,  90 => 39,  84 => 38,  81 => 37,  78 => 36,  75 => 35,  73 => 34,  68 => 33,  65 => 32,  62 => 30,  44 => 29,  39 => 27,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-nav.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/navigation/header/menu--header-nav.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 29, "set" => 32, "if" => 35, "include" => 75);
        static $filters = array("escape" => 27, "join" => 64);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['for', 'set', 'if', 'include'],
                ['escape', 'join'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
