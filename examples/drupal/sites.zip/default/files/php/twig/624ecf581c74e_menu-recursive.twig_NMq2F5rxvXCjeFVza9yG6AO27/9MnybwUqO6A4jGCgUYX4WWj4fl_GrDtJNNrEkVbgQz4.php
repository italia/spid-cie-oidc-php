<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia_components/link-list/menu-recursive.twig */
class __TwigTemplate_93be384db3fb850ac05a5bba4eb81919dd264de477e529026b973a3650fd09d8 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 34
        $macros["menus"] = $this->macros["menus"] = $this;
        // line 35
        echo "
";
        // line 40
        echo "
";
        // line 41
        $context["icon_position"] = ((($context["icon_position"] ?? null)) ? (($context["icon_position"] ?? null)) : ("right"));
        // line 42
        $context["icon_type"] = ((($context["icon_type"] ?? null)) ? (($context["icon_type"] ?? null)) : ("it-expand"));
        // line 43
        $context["icon_color"] = ((($context["icon_color"] ?? null)) ? (($context["icon_color"] ?? null)) : ("primary"));
        // line 44
        echo "
<div class=\"link-list-wrapper\">
  <ul class=\"link-list\">
    ";
        // line 47
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(twig_call_macro($macros["menus"], "macro_menu_links", [($context["items"] ?? null), ($context["attributes"] ?? null), 0, ($context["view_link_description"] ?? null), ($context["large"] ?? null), ($context["bold"] ?? null), ($context["icon_position"] ?? null), ($context["icon_type"] ?? null), ($context["icon_color"] ?? null), ($context["active_items_large"] ?? null), ($context["active_items_bold"] ?? null)], 47, $context, $this->getSourceContext()));
        echo "
  </ul>
</div>

";
    }

    // line 51
    public function macro_menu_links($__items__ = null, $__attributes__ = null, $__menu_level__ = null, $__view_link_description__ = null, $__large__ = null, $__bold__ = null, $__icon_position__ = null, $__icon_type__ = null, $__icon_color__ = null, $__active_items_large__ = null, $__active_items_bold__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "items" => $__items__,
            "attributes" => $__attributes__,
            "menu_level" => $__menu_level__,
            "view_link_description" => $__view_link_description__,
            "large" => $__large__,
            "bold" => $__bold__,
            "icon_position" => $__icon_position__,
            "icon_type" => $__icon_type__,
            "icon_color" => $__icon_color__,
            "active_items_large" => $__active_items_large__,
            "active_items_bold" => $__active_items_bold__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start(function () { return ''; });
        try {
            // line 52
            echo "  ";
            $macros["menus"] = $this;
            // line 53
            echo "
  ";
            // line 54
            if (($context["items"] ?? null)) {
                // line 55
                echo "    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["items"] ?? null));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["uuid"] => $context["item"]) {
                    // line 56
                    echo "      <li";
                    echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "attributes", [], "any", false, false, true, 56), 56, $this->source), "html", null, true);
                    echo ">

        ";
                    // line 58
                    if ((twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 58) == "<divider>")) {
                        // line 59
                        echo "          <span class=\"divider\"></span>

        ";
                    } elseif (($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(twig_get_attribute($this->env, $this->source,                     // line 61
$context["item"], "url", [], "any", false, false, true, 61)) == "<title>")) {
                        // line 62
                        echo "          <h3>";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 62), 62, $this->source), "html", null, true);
                        echo "</h3>

        ";
                    } else {
                        // line 65
                        echo "          ";
                        $context["item_classes"] = [0 => "list-item", 1 => ((twig_get_attribute($this->env, $this->source,                         // line 67
$context["item"], "in_active_trail", [], "any", false, false, true, 67)) ? ("active") : ("")), 2 => (((twig_get_attribute($this->env, $this->source,                         // line 68
$context["item"], "in_active_trail", [], "any", false, false, true, 68) && ($context["active_items_large"] ?? null))) ? ("large") : ("")), 3 => (((twig_get_attribute($this->env, $this->source,                         // line 69
$context["item"], "in_active_trail", [], "any", false, false, true, 69) && ($context["active_items_bold"] ?? null))) ? ("medium") : ("")), 4 => ((                        // line 70
($context["large"] ?? null)) ? ("large") : ("")), 5 => ((                        // line 71
($context["bold"] ?? null)) ? ("medium") : ("")), 6 => (((twig_get_attribute($this->env, $this->source,                         // line 72
$context["item"], "is_expanded", [], "any", false, false, true, 72) && (($context["icon_position"] ?? null) == "right"))) ? ("right-icon") : ("")), 7 => (((twig_get_attribute($this->env, $this->source,                         // line 73
$context["item"], "is_expanded", [], "any", false, false, true, 73) && (($context["icon_position"] ?? null) == "left"))) ? ("icon-left") : (""))];
                        // line 75
                        echo "          <a
            class=\"";
                        // line 76
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, twig_trim_filter(twig_join_filter($this->sandbox->ensureToStringAllowed(($context["item_classes"] ?? null), 76, $this->source), " ")), "html", null, true);
                        echo "\"
            ";
                        // line 77
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((twig_get_attribute($this->env, $this->source, $context["item"], "is_expanded", [], "any", false, false, true, 77)) ? ("data-toggle=\"collapse\" aria-expandend=\"true\"") : ("")));
                        echo "
            href=\"";
                        // line 78
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((twig_get_attribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 78)) ? (("#" . \Drupal\Component\Utility\Html::getId($this->sandbox->ensureToStringAllowed($context["uuid"], 78, $this->source)))) : (twig_get_attribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, true, 78))), "html", null, true);
                        echo "\"
            ";
                        // line 79
                        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "original_link", [], "any", false, false, true, 79), "getDescription", [], "method", false, false, true, 79)) {
                            // line 80
                            echo "              title=\"";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "original_link", [], "any", false, false, true, 80), "getDescription", [], "method", false, false, true, 80), 80, $this->source), "html", null, true);
                            echo "\"
            ";
                        }
                        // line 82
                        echo "          >
            <span>";
                        // line 83
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 83), 83, $this->source), "html", null, true);
                        echo "</span>
            ";
                        // line 84
                        if (twig_get_attribute($this->env, $this->source, $context["item"], "is_expanded", [], "any", false, false, true, 84)) {
                            // line 85
                            echo "              ";
                            $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia_components/link-list/menu-recursive.twig", 85)->display(twig_array_merge($context, ["name" =>                             // line 86
($context["icon_type"] ?? null), "classes" => [0 => ("icon-" .                             // line 87
($context["icon_color"] ?? null)), 1 => ("icon-" . ($context["icon_position"] ?? null))]]));
                            // line 89
                            echo "            ";
                        }
                        // line 90
                        echo "          ";
                        if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "original_link", [], "any", false, false, true, 90), "getDescription", [], "method", false, false, true, 90) && ($context["view_link_description"] ?? null))) {
                            // line 91
                            echo "            <p>";
                            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "original_link", [], "any", false, false, true, 91), "getDescription", [], "method", false, false, true, 91), 91, $this->source), "html", null, true);
                            echo "</p>
          ";
                        }
                        // line 93
                        echo "          </a>
        ";
                    }
                    // line 95
                    echo "
        ";
                    // line 97
                    echo "        ";
                    if (twig_get_attribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 97)) {
                        // line 98
                        echo "          <ul id=\"";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, \Drupal\Component\Utility\Html::getId($this->sandbox->ensureToStringAllowed($context["uuid"], 98, $this->source)), "html", null, true);
                        echo "\" class=\"link-sublist collapse ";
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((twig_get_attribute($this->env, $this->source, $context["item"], "in_active_trail", [], "any", false, false, true, 98)) ? ("show") : ("")));
                        echo "\">
            ";
                        // line 99
                        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(twig_call_macro($macros["menus"], "macro_menu_links", [twig_get_attribute($this->env, $this->source, $context["item"], "below", [], "any", false, false, true, 99), ($context["attributes"] ?? null), (($context["menu_level"] ?? null) + 1), ($context["view_link_description"] ?? null), ($context["large"] ?? null), ($context["bold"] ?? null), ($context["icon_position"] ?? null), ($context["icon_type"] ?? null), ($context["icon_color"] ?? null), ($context["active_items_large"] ?? null), ($context["active_items_bold"] ?? null)], 99, $context, $this->getSourceContext()));
                        echo "
          </ul>
        ";
                    }
                    // line 102
                    echo "
      </li>
    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['uuid'], $context['item'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 105
                echo "  ";
            }

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia_components/link-list/menu-recursive.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  235 => 105,  219 => 102,  213 => 99,  206 => 98,  203 => 97,  200 => 95,  196 => 93,  190 => 91,  187 => 90,  184 => 89,  182 => 87,  181 => 86,  179 => 85,  177 => 84,  173 => 83,  170 => 82,  164 => 80,  162 => 79,  158 => 78,  154 => 77,  150 => 76,  147 => 75,  145 => 73,  144 => 72,  143 => 71,  142 => 70,  141 => 69,  140 => 68,  139 => 67,  137 => 65,  130 => 62,  128 => 61,  124 => 59,  122 => 58,  116 => 56,  98 => 55,  96 => 54,  93 => 53,  90 => 52,  67 => 51,  58 => 47,  53 => 44,  51 => 43,  49 => 42,  47 => 41,  44 => 40,  41 => 35,  39 => 34,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia_components/link-list/menu-recursive.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/src/components/link-list/menu-recursive.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("import" => 34, "set" => 41, "macro" => 51, "if" => 54, "for" => 55, "include" => 85);
        static $filters = array("escape" => 56, "render" => 61, "trim" => 76, "join" => 76, "clean_id" => 78);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['import', 'set', 'macro', 'if', 'for', 'include'],
                ['escape', 'render', 'trim', 'join', 'clean_id'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
