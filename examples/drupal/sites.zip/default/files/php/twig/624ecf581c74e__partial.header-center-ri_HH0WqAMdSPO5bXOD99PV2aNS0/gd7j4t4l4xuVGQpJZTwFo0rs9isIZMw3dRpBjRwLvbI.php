<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/layout/header/_partial.header-center-right-zone.html.twig */
class __TwigTemplate_12ab70c173c5379bd7cd3182d880b31a01de9c1755f8bf0f8a950d5eac691962 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"it-right-zone\">
  ";
        // line 2
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_center_social", [], "any", false, false, true, 2)) {
            // line 3
            echo "    ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_center_social", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
            echo "
  ";
        } else {
            // line 5
            echo "    ";
            $this->loadTemplate("@bootstrap_italia_components/social/social.twig", "@bootstrap_italia/layout/header/_partial.header-center-right-zone.html.twig", 5)->display($context);
            // line 6
            echo "  ";
        }
        // line 7
        echo "  ";
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header_center_search", [], "any", false, false, true, 7)) {
            // line 8
            echo "    <div class=\"it-search-wrapper\">
      <span class=\"d-none d-md-block\">Cerca</span>
      <a class=\"search-link rounded-icon\" aria-label=\"Cerca\" href=\"#\" data-target=\"#search-modal\" data-toggle=\"modal\">
        ";
            // line 11
            $this->loadTemplate("@bootstrap_italia_components/icon/icon.twig", "@bootstrap_italia/layout/header/_partial.header-center-right-zone.html.twig", 11)->display(twig_array_merge($context, ["name" => "it-search"]));
            // line 12
            echo "      </a>
    </div>
  ";
        }
        // line 15
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/layout/header/_partial.header-center-right-zone.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 15,  66 => 12,  64 => 11,  59 => 8,  56 => 7,  53 => 6,  50 => 5,  44 => 3,  42 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/layout/header/_partial.header-center-right-zone.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/header/_partial.header-center-right-zone.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 2, "include" => 5);
        static $filters = array("escape" => 3);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'include'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
