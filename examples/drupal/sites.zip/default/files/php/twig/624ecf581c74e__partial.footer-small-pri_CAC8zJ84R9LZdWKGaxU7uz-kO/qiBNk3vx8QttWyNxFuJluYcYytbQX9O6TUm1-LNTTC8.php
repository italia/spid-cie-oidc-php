<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @bootstrap_italia/layout/footer/_partial.footer-small-prints.html.twig */
class __TwigTemplate_539f298a8b3592a7c241cb8ea1cbb75acfffc4fdc9c8af4d6134d26f294fe8e5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo " ";
        if ((twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_small_prints", [], "any", false, false, true, 1) || twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_credits", [], "any", false, false, true, 1))) {
            // line 2
            echo "   ";
            // line 3
            $context["region1_classes"] = (((twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_small_prints", [], "any", false, false, true, 3) && twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_credits", [], "any", false, false, true, 3))) ? ("col-lg-9 col-md-7") : ("col"));
            // line 5
            echo "   ";
            // line 6
            $context["region2_classes"] = (((twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_small_prints", [], "any", false, false, true, 6) && twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_credits", [], "any", false, false, true, 6))) ? ("col-lg-3 col-md-5") : ("col"));
            // line 8
            echo "  <div class=\"row\">
    ";
            // line 9
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_small_prints", [], "any", false, false, true, 9)) {
                // line 10
                echo "      <div class=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["region1_classes"] ?? null), 10, $this->source), "html", null, true);
                echo "\">
        ";
                // line 11
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_small_prints", [], "any", false, false, true, 11), 11, $this->source), "html", null, true);
                echo "
      </div>
    ";
            }
            // line 14
            echo "    ";
            if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_credits", [], "any", false, false, true, 14)) {
                // line 15
                echo "      <div class=\"";
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["region2_classes"] ?? null), 15, $this->source), "html", null, true);
                echo "\">
        ";
                // line 16
                echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_credits", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
                echo "
      </div>
    ";
            }
            // line 19
            echo "  </div>
 ";
        }
    }

    public function getTemplateName()
    {
        return "@bootstrap_italia/layout/footer/_partial.footer-small-prints.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 19,  74 => 16,  69 => 15,  66 => 14,  60 => 11,  55 => 10,  53 => 9,  50 => 8,  48 => 6,  46 => 5,  44 => 3,  42 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@bootstrap_italia/layout/footer/_partial.footer-small-prints.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/layout/footer/_partial.footer-small-prints.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 1, "set" => 3);
        static $filters = array("escape" => 10);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'set'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
