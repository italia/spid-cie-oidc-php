<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/navigation/pager.html.twig */
class __TwigTemplate_499ed3529ee62fcd46d19c66dd8f1481ae425ee77da4f1f6a53ab9f6de07d32c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 34
        $this->loadTemplate("@bootstrap_italia_components/pagination/pagination-full.twig", "themes/contrib/bootstrap_italia/templates/navigation/pager.html.twig", 34)->display(twig_array_merge($context, ["heading_id" =>         // line 35
($context["heading_id"] ?? null), "items" =>         // line 36
($context["items"] ?? null), "total_pages" =>         // line 37
($context["total_pages"] ?? null), "current" =>         // line 38
($context["current"] ?? null), "ellipses" =>         // line 39
($context["ellipses"] ?? null)]));
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/navigation/pager.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 39,  43 => 38,  42 => 37,  41 => 36,  40 => 35,  39 => 34,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/navigation/pager.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/navigation/pager.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("include" => 34);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['include'],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
