<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/navigation/breadcrumb.html.twig */
class __TwigTemplate_89bd662275072832abc2e057d928be200fdf315341ffd68d1041332ff8f6cc41 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 10
        if (($context["breadcrumb"] ?? null)) {
            // line 11
            $this->loadTemplate("@bootstrap_italia_components/breadcrumb/breadcrumb.twig", "themes/contrib/bootstrap_italia/templates/navigation/breadcrumb.html.twig", 11)->display(twig_array_merge($context, ["breadcrumb_dark_background" =>             // line 12
($context["breadcrumb_dark_background"] ?? null), "breadcrumb_image" =>             // line 13
($context["breadcrumb_image"] ?? null), "breadcrumb_separator" =>             // line 14
($context["breadcrumb_separator"] ?? null), "breadcrumb" =>             // line 15
($context["breadcrumb"] ?? null)]));
        }
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/navigation/breadcrumb.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 15,  44 => 14,  43 => 13,  42 => 12,  41 => 11,  39 => 10,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/navigation/breadcrumb.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/navigation/breadcrumb.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 10, "include" => 11);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if', 'include'],
                [],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
