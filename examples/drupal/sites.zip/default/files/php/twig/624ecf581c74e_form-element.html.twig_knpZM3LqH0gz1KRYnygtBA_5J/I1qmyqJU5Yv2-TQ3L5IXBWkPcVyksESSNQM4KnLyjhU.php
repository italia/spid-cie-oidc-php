<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/contrib/bootstrap_italia/templates/form/form-element.html.twig */
class __TwigTemplate_1b4f98a7a4cb9d375bbe95b2e502e1bd09fc108db8c9da040031224d8ba01d2d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 47
        $macros["macros"] = $this->macros["macros"] = $this->loadTemplate("@bootstrap_italia/macros.twig", "themes/contrib/bootstrap_italia/templates/form/form-element.html.twig", 47)->unwrap();
        // line 49
        $context["classes"] = [0 => "js-form-item", 1 => "form-item", 2 => (((((        // line 52
($context["type"] ?? null) != "checkbox") && (($context["type"] ?? null) != "radio")) && (($context["type"] ?? null) != "select"))) ? ("form-group") : ("")), 3 => (((        // line 53
($context["type"] ?? null) == "checkbox")) ? ("form-check") : ("")), 4 => (((        // line 54
($context["type"] ?? null) == "radio")) ? ("form-check") : ("")), 5 => (((        // line 55
($context["type"] ?? null) == "select")) ? ("bootstrap-select-wrapper") : ("")), 6 => ("js-form-type-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(        // line 56
($context["type"] ?? null), 56, $this->source))), 7 => ("form-item-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(        // line 57
($context["name"] ?? null), 57, $this->source))), 8 => ("js-form-item-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(        // line 58
($context["name"] ?? null), 58, $this->source))), 9 => ((!twig_in_filter(        // line 59
($context["title_display"] ?? null), [0 => "after", 1 => "before"])) ? ("form-no-label") : ("")), 10 => (((        // line 60
($context["disabled"] ?? null) == "disabled")) ? ("form-disabled") : ("")), 11 => ((        // line 61
($context["errors"] ?? null)) ? ("form-item--error") : (""))];
        // line 65
        $context["description_classes"] = [0 => "description", 1 => (((        // line 67
($context["description_display"] ?? null) == "invisible")) ? ("visually-hidden") : ("")), 2 => "form-text", 3 => "text-muted"];
        // line 72
        echo "<div";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => ($context["classes"] ?? null)], "method", false, false, true, 72), 72, $this->source), "html", null, true);
        echo ">
  ";
        // line 73
        if (twig_in_filter(($context["label_display"] ?? null), [0 => "before", 1 => "invisible"])) {
            // line 74
            echo "    ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["label"] ?? null), 74, $this->source), "html", null, true);
            echo "
  ";
        }
        // line 76
        echo "  ";
        if ( !twig_test_empty(($context["prefix"] ?? null))) {
            // line 77
            echo "    <div class=\"input-group-prepend\">
      <span class=\"field-prefix input-group-text\">";
            // line 78
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["prefix"] ?? null), 78, $this->source), "html", null, true);
            echo "</span>
    </div>
  ";
        }
        // line 81
        echo "  ";
        if (((($context["description_display"] ?? null) == "before") && twig_get_attribute($this->env, $this->source, ($context["description"] ?? null), "content", [], "any", false, false, true, 81))) {
            // line 82
            echo "    <small";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["description"] ?? null), "attributes", [], "any", false, false, true, 82), 82, $this->source), "html", null, true);
            echo ">
      ";
            // line 83
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["description"] ?? null), "content", [], "any", false, false, true, 83), 83, $this->source), "html", null, true);
            echo "
    </small>
  ";
        }
        // line 86
        echo "  ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["children"] ?? null), 86, $this->source), "html", null, true);
        echo "
  ";
        // line 87
        if ((($context["type"] ?? null) == "password")) {
            // line 88
            echo "    ";
            $this->loadTemplate("@bootstrap_italia_components/icon/password_icon.twig", "themes/contrib/bootstrap_italia/templates/form/form-element.html.twig", 88)->display($context);
            // line 89
            echo "  ";
        }
        // line 90
        echo "  ";
        if ( !twig_test_empty(($context["suffix"] ?? null))) {
            // line 91
            echo "    <div class=\"input-group-append\">
      <span class=\"field-suffix input-group-text\">";
            // line 92
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["suffix"] ?? null), 92, $this->source), "html", null, true);
            echo "</a></span>
    </div>
  ";
        }
        // line 95
        echo "  ";
        if ((($context["label_display"] ?? null) == "after")) {
            // line 96
            echo "    ";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["label"] ?? null), 96, $this->source), "html", null, true);
            echo "
  ";
        }
        // line 98
        echo "  ";
        if (($context["errors"] ?? null)) {
            // line 99
            echo "    <div class=\"form-item--error-message invalid-feedback\">
      ";
            // line 100
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["errors"] ?? null), 100, $this->source), "html", null, true);
            echo "
    </div>
    ";
            // line 108
            echo "  ";
        }
        // line 109
        echo "  ";
        if ((twig_in_filter(($context["description_display"] ?? null), [0 => "after", 1 => "invisible"]) && twig_get_attribute($this->env, $this->source, ($context["description"] ?? null), "content", [], "any", false, false, true, 109))) {
            // line 110
            echo "    <small";
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["description"] ?? null), "attributes", [], "any", false, false, true, 110), "addClass", [0 => ($context["description_classes"] ?? null)], "method", false, false, true, 110), 110, $this->source), "html", null, true);
            echo ">
      ";
            // line 111
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["description"] ?? null), "content", [], "any", false, false, true, 111), 111, $this->source), "html", null, true);
            echo "
    </small>
  ";
        }
        // line 114
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "themes/contrib/bootstrap_italia/templates/form/form-element.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  157 => 114,  151 => 111,  146 => 110,  143 => 109,  140 => 108,  135 => 100,  132 => 99,  129 => 98,  123 => 96,  120 => 95,  114 => 92,  111 => 91,  108 => 90,  105 => 89,  102 => 88,  100 => 87,  95 => 86,  89 => 83,  84 => 82,  81 => 81,  75 => 78,  72 => 77,  69 => 76,  63 => 74,  61 => 73,  56 => 72,  54 => 67,  53 => 65,  51 => 61,  50 => 60,  49 => 59,  48 => 58,  47 => 57,  46 => 56,  45 => 55,  44 => 54,  43 => 53,  42 => 52,  41 => 49,  39 => 47,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/contrib/bootstrap_italia/templates/form/form-element.html.twig", "/home/drupal/web/themes/contrib/bootstrap_italia/templates/form/form-element.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("import" => 47, "set" => 49, "if" => 73, "include" => 88);
        static $filters = array("clean_class" => 56, "escape" => 72);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['import', 'set', 'if', 'include'],
                ['clean_class', 'escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
